﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace StellarProject
{
    class Program
    {
        private static int openIndex;

        private static int closeIndex;

        private static string[] objData;

        private static List<Galaxies> galaxies = new List<Galaxies>();

        public static int CloseIndex { get => closeIndex; set => closeIndex = value; }

        static void Main()
        {
            Console.WriteLine("add a galaxy:");
            string line = Console.ReadLine();
            string[] commands = line.Split(' ');

            while (commands[0] != "exit")
            {
                switch (commands[0])
                {
                    case "add":
                        switch (commands[1])
                        {
                            case "galaxy":
                                AddGalaxy(line);
                                Console.WriteLine("add a star:");
                                break;

                            case "star":
                                AddStar(line);
                                Console.WriteLine("add a planet:");
                                break;

                            case "planet":
                                Console.WriteLine("add a moon (if any):");
                                AddPlanet(line);
                                break;

                            case "moon":
                                AddMoon(line);
                                break;
                        }

                        break;

                    case "list":
                        List<string> objNames = new List<string>();
                        var objectToList = commands[1];

                        switch (objectToList)
                        {
                            case "galaxies":

                                if (galaxies.Count == 0)
                                {
                                    Console.WriteLine("none");
                                    break;
                                }

                                Console.WriteLine("--- List of all researched galaxies ---");

                                foreach (var g in galaxies)
                                {
                                    Console.WriteLine(g.Name);
                                }

                                Console.WriteLine("--- End of galaxies list ---");
                                break;

                            case "stars":

                                objNames.AddRange(
                                    from g in galaxies
                                    from s in g.Stars
                                    select s.Name);

                                if (objNames.Count == 0)
                                {
                                    Console.WriteLine("none");
                                    break;
                                }

                                Console.WriteLine("--- List of all researched stars ---");

                                foreach (var s in objNames)
                                {
                                    Console.WriteLine(s);
                                }

                                Console.WriteLine("--- End of stars list ---");
                                break;

                            case "planets":

                                objNames.AddRange(
                                    from g in galaxies
                                    from s in g.Stars
                                    from p in s.Planets
                                    select p.Name);

                                if (objNames.Count == 0)
                                {
                                    Console.WriteLine("none");
                                    break;
                                }

                                Console.WriteLine("--- List of all researched planets ---");

                                foreach (var p in objNames)
                                {
                                    Console.WriteLine(p);
                                }

                                Console.WriteLine("--- End of planets list ---");
                                break;

                            case "moons":
                                objNames.AddRange(from g in galaxies
                                                  from s in g.Stars
                                                  from p in s.Planets
                                                  from m in p.Moons
                                                  select m.Name);

                                Console.WriteLine("--- List of all researched moon ---");

                                foreach (var m in objNames)
                                {
                                    Console.WriteLine(m);
                                }

                                Console.WriteLine("--- End of moon list ---");
                                break;
                        }

                        objNames.Clear();
                        break;

                    case "stats":
                        ShowStats();
                        break;

                    case "print":
                        PrintGalaxy(line);
                        break;
                }

                line = Console.ReadLine();
                if (line != null) commands = line.Split(' ');
            }

            
        }

        private static void PrintGalaxy(string line)
        {
            openIndex = line.IndexOf('[') + 1;
            closeIndex = line.IndexOf(']');

            var galaxyToSearch = line.Substring(openIndex, closeIndex - openIndex);

            var foundGalaxy = galaxies.FirstOrDefault(g => g.Name == galaxyToSearch);

            if (foundGalaxy == null)
            {
                Console.WriteLine("none");
            }
            else
            {
                Console.WriteLine("--- Data for {0} galaxy ---", foundGalaxy.Name);
                Console.Write(foundGalaxy);
                Console.WriteLine("--- End of data for {0} galaxy ---", foundGalaxy.Name);
            }
        }

        private static void ShowStats()
        {
            Console.WriteLine("--- Stats ---");

            Console.WriteLine("Galaxies: " + galaxies.Count);

            int starsCount = galaxies.SelectMany(g => g.Stars).Count();

            Console.WriteLine("Stars: " + starsCount);

            int planetsCount = (from g in galaxies from s in g.Stars from p in s.Planets select p).Count();

            Console.WriteLine("Planets: " + planetsCount);

            int moonsCount = (from g in galaxies from s in g.Stars from p in s.Planets from m in p.Moons select m).Count();

            Console.WriteLine("Moons: " + moonsCount);
            Console.WriteLine("--- End of stats ---");
        }

        private static void AddMoon(string line)
        {
            openIndex = line.IndexOf('[');
            closeIndex = line.IndexOf(']');

            var planetName = line.Substring(openIndex + 1, closeIndex - openIndex - 1);

            openIndex = line.IndexOf(']', openIndex) + 3;
            closeIndex = line.LastIndexOf(']');

            var moonName = line.Substring(openIndex, closeIndex - openIndex);

            foreach (var s in galaxies.SelectMany(g => g.Stars))
            {
                foreach (var p in s.Planets.Where(p => p.Name == planetName))
                {
                    p.Moons.Add(new Moons(moonName));
                    break;
                }
            }
        }

        private static void AddPlanet(string line)
        {
            openIndex = line.IndexOf('[');
            closeIndex = line.IndexOf(']');

            var starName = line.Substring(openIndex + 1, closeIndex - openIndex - 1);

            openIndex = line.IndexOf(']', openIndex) + 3;
            closeIndex = line.LastIndexOf(']');

            var planetName = line.Substring(openIndex, closeIndex - openIndex);

            objData = line
                .Substring(closeIndex + 1, line.Length - closeIndex - 1)
                .Split(' ');

            var newPlanet = new Planets(planetName, objData[1], objData[2] == "yes");

            foreach (var g in galaxies)
            {
                foreach (var s in g.Stars.Where(s => s.Name == starName))
                {
                    s.Planets.Add(newPlanet);
                    break;
                }
            }
        }

        private static void AddStar(string line)
        {
            openIndex = line.IndexOf('[');
            closeIndex = line.IndexOf(']');

            var galaxyName = line.Substring(openIndex + 1, closeIndex - openIndex - 1);

            openIndex = line.IndexOf(']', openIndex) + 3;
            closeIndex = line.LastIndexOf(']');

            var starName = line.Substring(openIndex, closeIndex - openIndex);

            objData = line
                .Substring(closeIndex + 1, line.Length - closeIndex - 1)
                .Split(' ');

            var star = new Stars(
                starName,
                Convert.ToDecimal(objData[1]),
                Convert.ToDecimal(objData[2]),
                Convert.ToInt64(objData[3]),
                Convert.ToDecimal(objData[4]));

            foreach (var galaxy in galaxies.Where(galaxy => galaxy.Name == galaxyName))
            {
                galaxy.Stars.Add(star);
                break;
            }
        }

        private static void AddGalaxy(string line)
        {
            openIndex = line.IndexOf('[') + 1;
            closeIndex = line.IndexOf(']');

            var objName = line.Substring(openIndex, closeIndex - openIndex);

            objData = line
                .Substring(closeIndex + 1, line.Length - closeIndex - 1)
                .Split(' ');

            var ageString = objData[2];
            var age = decimal.Parse(ageString.Remove(ageString.Length - 1, 1));
            var ageChar = ageString[^1];
            galaxies.Add(new Galaxies(objName, objData[1], age, ageChar));
          }
    }
}