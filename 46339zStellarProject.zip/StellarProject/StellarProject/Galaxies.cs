﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StellarProject
{
    public class Galaxies
    {
        public string Name { get; }

        public string Type { get; }

        public decimal Age { get; }

        public char AgeChar { get; }

        public List<Stars> Stars { get; }

        public Galaxies(string name, string type, decimal age, char ageChar)
        {
            Name = name;
            Type = type;
            Age = age;
            AgeChar = ageChar;

            Stars = new List<Stars>();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Type: " + Type);
            sb.AppendLine("Age: " + Age + AgeChar);

            if (Stars.Count <= 0) return sb.ToString();

            sb.AppendLine("Stars:");
            Stars.ForEach(s => sb.Append(s));

            return sb.ToString();
        }
    }
}