﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StellarProject
{
    public class Planets
    {
        public string Name { get; }

        public string Type { get; }

        public bool IsHabitable { get; }

        public List<Moons> Moons { get; }

        public Planets(string name, string type, bool isHabitable)
        {
            Name = name;
            Type = type;
            IsHabitable = isHabitable;

            Moons = new List<Moons>();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{new string(' ', 15)}Name: " + Name);
            sb.AppendLine($"{new string(' ', 15)}Type: " + Type);
            sb.AppendLine($"{new string(' ', 15)}Support life: " + (IsHabitable ? "yes" : "no"));

            if (Moons.Count <= 0)
            {
                return sb.ToString();
            }

            sb.AppendLine($"{new string(' ', 15)}Moons:");
            Moons.ForEach(p => sb.AppendLine(p.ToString()));

            return sb.ToString();
        }
    }
}