﻿using System;
using System.Text;
using System.Collections.Generic;

namespace StellarProject
{
    public class Moons
    {
        public string Name { get; set; }

        public Moons(string name)
        {
            Name = name;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($@"{new string(' ', 25)}{Name}");
            return sb.ToString();
        }
    }
}